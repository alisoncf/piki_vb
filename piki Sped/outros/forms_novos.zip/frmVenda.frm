VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Object = "{C18424FD-277B-4362-B7A8-2788E7DBF8B4}#1.0#0"; "QPROGIF.OCX"
Begin VB.Form frmVenda 
   AutoRedraw      =   -1  'True
   BackColor       =   &H8000000B&
   BorderStyle     =   0  'None
   Caption         =   "Venda de Produtos:"
   ClientHeight    =   9000
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   12000
   ControlBox      =   0   'False
   Icon            =   "frmVenda.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9000
   ScaleWidth      =   12000
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.PictureBox pcECF 
      Appearance      =   0  'Flat
      BackColor       =   &H0000C000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   45
      Left            =   120
      ScaleHeight     =   45
      ScaleWidth      =   5175
      TabIndex        =   31
      Top             =   7920
      Width           =   5175
   End
   Begin VB.Frame frControle 
      BorderStyle     =   0  'None
      Height          =   8535
      Left            =   120
      TabIndex        =   0
      Top             =   -120
      Width           =   11535
      Begin VB.PictureBox pcMsg 
         Appearance      =   0  'Flat
         BackColor       =   &H8000000A&
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   375
         Left            =   0
         Picture         =   "frmVenda.frx":08CA
         ScaleHeight     =   345
         ScaleWidth      =   11385
         TabIndex        =   56
         Top             =   8160
         Width           =   11415
         Begin VB.Label lblMensagem 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   9.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   5745
            TabIndex        =   58
            Top             =   0
            Width           =   135
         End
         Begin VB.Label lblHora 
            Alignment       =   1  'Right Justify
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "00:00:00"
            Height          =   195
            Left            =   10680
            TabIndex        =   57
            Top             =   120
            Width           =   630
         End
      End
      Begin VB.Frame frmCli 
         Appearance      =   0  'Flat
         BackColor       =   &H00D3E7EB&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   7335
         Left            =   0
         TabIndex        =   1
         Top             =   720
         Width           =   5175
         Begin VB.PictureBox pcPro 
            Appearance      =   0  'Flat
            BackColor       =   &H00D3E7EB&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   1335
            Left            =   0
            Picture         =   "frmVenda.frx":8F30
            ScaleHeight     =   1335
            ScaleWidth      =   5175
            TabIndex        =   59
            Top             =   4440
            Width           =   5175
            Begin VB.Timer Timer1 
               Interval        =   200
               Left            =   4080
               Top             =   240
            End
            Begin VB.Label lblProp 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "Agradecemos a prefer�ncia... Tenha um Feliz Natal..."
               BeginProperty Font 
                  Name            =   "Monotype Corsiva"
                  Size            =   14.25
                  Charset         =   0
                  Weight          =   400
                  Underline       =   0   'False
                  Italic          =   -1  'True
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   330
               Left            =   120
               TabIndex        =   60
               Top             =   960
               Width           =   5385
            End
         End
         Begin prjQProGIF.QProGIF QProGIF1 
            Height          =   1575
            Left            =   0
            TabIndex        =   61
            Top             =   5760
            Width           =   5175
            _ExtentX        =   9128
            _ExtentY        =   2778
            Filename        =   "C:\market\gifs\maebela3.gif"
         End
         Begin VB.Label lblCapPro 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Produto:"
            Height          =   195
            Left            =   120
            TabIndex        =   47
            Top             =   1440
            Width           =   600
         End
         Begin VB.Label lblProduto 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   120
            TabIndex        =   46
            Top             =   1680
            Width           =   4845
         End
         Begin VB.Label Label13 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Marca:"
            Height          =   195
            Left            =   120
            TabIndex        =   45
            Top             =   2040
            Width           =   495
         End
         Begin VB.Label lblMarca 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   120
            TabIndex        =   44
            Top             =   2280
            Width           =   2325
         End
         Begin VB.Label Label15 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Categoria:"
            Height          =   195
            Left            =   2640
            TabIndex        =   43
            Top             =   2040
            Width           =   720
         End
         Begin VB.Label lblCat 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   2640
            TabIndex        =   42
            Top             =   2280
            Width           =   2325
         End
         Begin VB.Label Label17 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "C�d:"
            Height          =   195
            Left            =   120
            TabIndex        =   41
            Top             =   2640
            Width           =   330
         End
         Begin VB.Label lblCod 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   120
            TabIndex        =   40
            Top             =   2880
            Width           =   2325
         End
         Begin VB.Label Label19 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "C�d. Barra:"
            Height          =   195
            Left            =   2640
            TabIndex        =   39
            Top             =   2640
            Width           =   795
         End
         Begin VB.Label lblCodBarr 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   2640
            TabIndex        =   38
            Top             =   2880
            Width           =   2325
         End
         Begin VB.Label Label23 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Quantidade:"
            Height          =   195
            Left            =   2640
            TabIndex        =   37
            Top             =   3240
            Width           =   870
         End
         Begin VB.Label lblQtd 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   2640
            TabIndex        =   36
            Top             =   3480
            Width           =   2325
         End
         Begin VB.Label lblPreco 
            Appearance      =   0  'Flat
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H80000008&
            Height          =   315
            Left            =   120
            TabIndex        =   35
            Top             =   3480
            Width           =   2325
         End
         Begin VB.Label lblCapPreco 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Pre�o:"
            Height          =   195
            Left            =   120
            TabIndex        =   34
            Top             =   3240
            Width           =   465
         End
         Begin VB.Label lblRef 
            Appearance      =   0  'Flat
            BackColor       =   &H000000FF&
            BeginProperty Font 
               Name            =   "Times New Roman"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00C00000&
            Height          =   315
            Left            =   2640
            TabIndex        =   33
            Top             =   3960
            Width           =   2325
         End
         Begin VB.Label Label20 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Refer�ncia:"
            Height          =   195
            Left            =   1560
            TabIndex        =   32
            Top             =   4020
            Width           =   825
         End
         Begin VB.Label Label8 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Itens:"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   315
            Left            =   2040
            TabIndex        =   9
            Top             =   0
            Width           =   630
         End
         Begin VB.Label lblItens 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            Caption         =   "0"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H000000C0&
            Height          =   315
            Left            =   2880
            TabIndex        =   8
            Tag             =   "!"
            Top             =   0
            Width           =   135
         End
         Begin VB.Label lblProd 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            Caption         =   "0"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H000000C0&
            Height          =   315
            Left            =   1440
            TabIndex        =   5
            Tag             =   "!"
            Top             =   0
            Width           =   135
         End
         Begin VB.Label Label1 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Produtos:"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   315
            Left            =   120
            TabIndex        =   4
            Top             =   0
            Width           =   1095
         End
         Begin VB.Label Label9 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            Caption         =   "Total:"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   30
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00000000&
            Height          =   675
            Left            =   120
            TabIndex        =   3
            Top             =   600
            Width           =   1515
         End
         Begin VB.Label lblValor 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            Caption         =   "0,00"
            BeginProperty Font 
               Name            =   "Garamond"
               Size            =   48
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H000000C0&
            Height          =   1080
            Left            =   1920
            TabIndex        =   2
            Tag             =   "!"
            Top             =   360
            Width           =   1605
         End
      End
      Begin VB.Frame Frame1 
         BorderStyle     =   0  'None
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   7935
         Left            =   -120
         TabIndex        =   6
         Top             =   240
         Width           =   11655
         Begin VB.PictureBox pcAtalhos 
            Appearance      =   0  'Flat
            BackColor       =   &H00C6AE86&
            ForeColor       =   &H80000008&
            Height          =   375
            Left            =   120
            ScaleHeight     =   345
            ScaleWidth      =   11385
            TabIndex        =   48
            Top             =   0
            Width           =   11415
            Begin VB.Label Label2 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F12 - Sair"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   10440
               TabIndex        =   55
               Top             =   45
               Width           =   735
            End
            Begin VB.Label lblMsg1 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F3 - Edita Item  "
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   2160
               TabIndex        =   54
               Top             =   45
               Width           =   1230
            End
            Begin VB.Label lblMsg2 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F4 - Exclui o Item"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   3480
               TabIndex        =   53
               Top             =   45
               Width           =   1365
            End
            Begin VB.Label lblMsg 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F5 - Navega no Grid"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   5040
               TabIndex        =   52
               Top             =   45
               Width           =   1560
            End
            Begin VB.Label Label4 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F6 - Cancelar Venda"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   6840
               TabIndex        =   51
               Top             =   45
               Width           =   1620
            End
            Begin VB.Label Label5 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F7 - Conclui Venda"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   8640
               TabIndex        =   50
               Top             =   45
               Width           =   1515
            End
            Begin VB.Label Label6 
               AutoSize        =   -1  'True
               BackStyle       =   0  'Transparent
               Caption         =   "F2 - Buscar Produto"
               BeginProperty Font 
                  Name            =   "Arial"
                  Size            =   8.25
                  Charset         =   0
                  Weight          =   700
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               ForeColor       =   &H00000000&
               Height          =   210
               Left            =   360
               TabIndex        =   49
               Top             =   45
               Width           =   1605
            End
         End
         Begin VB.CommandButton cmndbtnLocaliza 
            Caption         =   "..."
            Height          =   255
            Left            =   9480
            TabIndex        =   30
            Top             =   7320
            Visible         =   0   'False
            Width           =   375
         End
         Begin MSDBGrid.DBGrid dbgrdProd 
            Bindings        =   "frmVenda.frx":A06E
            Height          =   6615
            Left            =   5400
            OleObjectBlob   =   "frmVenda.frx":A083
            TabIndex        =   7
            Top             =   480
            Width           =   6135
         End
         Begin VB.Frame Frame3 
            Height          =   735
            Left            =   5400
            TabIndex        =   16
            Top             =   7080
            Width           =   6135
            Begin VB.TextBox txtbxUnit 
               Alignment       =   1  'Right Justify
               BackColor       =   &H80000014&
               Enabled         =   0   'False
               Height          =   285
               Left            =   4320
               TabIndex        =   22
               Text            =   "0,00"
               Top             =   360
               Width           =   735
            End
            Begin VB.TextBox txtbxQtd 
               Alignment       =   1  'Right Justify
               BackColor       =   &H80000014&
               Enabled         =   0   'False
               Height          =   285
               Left            =   5160
               TabIndex        =   18
               Text            =   "1"
               Top             =   360
               Width           =   735
            End
            Begin VB.TextBox txtbxProduto 
               BackColor       =   &H80000014&
               Height          =   285
               Left            =   120
               TabIndex        =   17
               Top             =   360
               Width           =   4095
            End
            Begin VB.Label Label10 
               Appearance      =   0  'Flat
               AutoSize        =   -1  'True
               BackColor       =   &H80000005&
               BackStyle       =   0  'Transparent
               Caption         =   "&Unit:"
               ForeColor       =   &H80000008&
               Height          =   195
               Left            =   4560
               TabIndex        =   23
               Top             =   120
               Width           =   330
            End
            Begin VB.Label lblUltItem 
               Appearance      =   0  'Flat
               AutoSize        =   -1  'True
               BackColor       =   &H80000005&
               BackStyle       =   0  'Transparent
               Caption         =   "&Produto"
               ForeColor       =   &H80000008&
               Height          =   195
               Left            =   120
               TabIndex        =   21
               Top             =   120
               Width           =   555
            End
            Begin VB.Label Label3 
               Appearance      =   0  'Flat
               AutoSize        =   -1  'True
               BackColor       =   &H80000005&
               BackStyle       =   0  'Transparent
               Caption         =   "&Qtd:"
               ForeColor       =   &H80000008&
               Height          =   195
               Left            =   5160
               TabIndex        =   20
               Top             =   120
               Width           =   300
            End
            Begin VB.Label lblNome_pro 
               Appearance      =   0  'Flat
               AutoSize        =   -1  'True
               BackColor       =   &H80000005&
               BackStyle       =   0  'Transparent
               ForeColor       =   &H80000008&
               Height          =   195
               Left            =   720
               TabIndex        =   19
               Top             =   720
               Width           =   45
            End
         End
         Begin VB.Data dtProd 
            Caption         =   "Data1"
            Connect         =   "Access"
            DatabaseName    =   ""
            DefaultCursorType=   0  'DefaultCursor
            DefaultType     =   1  'UseODBC
            Exclusive       =   0   'False
            Height          =   495
            Left            =   8160
            Options         =   0
            ReadOnly        =   0   'False
            RecordsetType   =   1  'Dynaset
            RecordSource    =   ""
            Top             =   3600
            Visible         =   0   'False
            Width           =   1455
         End
         Begin VB.Frame Frame5 
            BorderStyle     =   0  'None
            Height          =   3015
            Left            =   0
            TabIndex        =   14
            Top             =   2040
            Width           =   5175
         End
         Begin VB.Frame Frame2 
            Height          =   855
            Left            =   120
            TabIndex        =   24
            Top             =   3960
            Visible         =   0   'False
            Width           =   5055
            Begin VB.TextBox txtbxNomeCli 
               Height          =   285
               Left            =   720
               TabIndex        =   27
               Top             =   360
               Width           =   3975
            End
            Begin VB.CommandButton cmndbtnCliente 
               Height          =   285
               Left            =   4680
               Picture         =   "frmVenda.frx":B144
               Style           =   1  'Graphical
               TabIndex        =   26
               Top             =   360
               Width           =   255
            End
            Begin VB.TextBox txtbxCod_Cli 
               Height          =   285
               Left            =   120
               MaxLength       =   5
               TabIndex        =   25
               Text            =   "00000"
               Top             =   360
               Width           =   615
            End
            Begin VB.Label Label12 
               AutoSize        =   -1  'True
               Caption         =   "&Cliente:"
               Height          =   195
               Left            =   720
               TabIndex        =   29
               Top             =   120
               Width           =   525
            End
            Begin VB.Label Label16 
               AutoSize        =   -1  'True
               Caption         =   "C&od:"
               Height          =   195
               Left            =   120
               TabIndex        =   28
               Top             =   120
               Width           =   330
            End
         End
      End
   End
   Begin VB.Label lblTur 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   6480
      TabIndex        =   65
      Top             =   8700
      Width           =   270
   End
   Begin VB.Label Label21 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Turno:"
      ForeColor       =   &H00000000&
      Height          =   195
      Left            =   6000
      TabIndex        =   64
      Top             =   8760
      Width           =   465
   End
   Begin VB.Label lblCaixa 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   5520
      TabIndex        =   63
      Top             =   8700
      Width           =   270
   End
   Begin VB.Label Label14 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Caixa:"
      ForeColor       =   &H00000000&
      Height          =   195
      Left            =   5040
      TabIndex        =   62
      Top             =   8760
      Width           =   435
   End
   Begin VB.Label lblNomeEmp 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "0000000000"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   10470
      TabIndex        =   15
      Top             =   8700
      Width           =   1350
   End
   Begin VB.Label Label11 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Controle:"
      ForeColor       =   &H00000000&
      Height          =   195
      Left            =   3240
      TabIndex        =   13
      Top             =   8760
      Width           =   630
   End
   Begin VB.Label lblnum_ven 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "0000000"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   3960
      TabIndex        =   12
      Top             =   8700
      Width           =   945
   End
   Begin VB.Label lblNome_Fun 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Nome do Atendente"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   960
      TabIndex        =   11
      Top             =   8700
      Width           =   2250
   End
   Begin VB.Label Label7 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Atendente:"
      ForeColor       =   &H00000000&
      Height          =   195
      Left            =   120
      TabIndex        =   10
      Top             =   8760
      Width           =   780
   End
End
Attribute VB_Name = "frmVenda"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Dim bActive As Boolean
Dim preco As Currency
Dim operacao As String
Dim iGif As Integer
Dim iItem As Integer
Sub P_Msg(msg As String)
    
    lblMensagem.caption = msg
    Me.Refresh
End Sub

Sub P_AtualizaVenda()
    Dim strSQL As String
    Dim cTotal As Currency
    Dim iPos As Integer
    Dim cItens As Integer
    P_Status "Atualizando Valores..."
    
    iPos = dtProd.Recordset.AbsolutePosition
    dtProd.Refresh
    With dtProd.Recordset
        
        
        Do While Not .EOF
            cTotal = cTotal + !Total
            cItens = cItens + !qtd_ite
            .MoveNext
        Loop
        lblValor.caption = FormatVal(CStr(cTotal))
        lblItens.caption = dtProd.Recordset.RecordCount
    End With
        
    
    lblValor.caption = FormatVal(CStr(cTotal))
    
    dtProd.Refresh
    dtProd.Recordset.Move iPos
    
    lblProd.caption = dtProd.Recordset.RecordCount
    lblItens.caption = cItens

    strSQL = "update tab_vendas set valor_ven =" & F_GravaDec(cTotal)
    strSQL = strSQL & ", nomecli_ven= '" & txtbxNomeCli.Text & "', "
    strSQL = strSQL & " cod_cli= '" & txtbxNomeCli.Tag & "' "
'    strSQL = strSQL & " obs_VEN='" & txtbxObs.Text & "' "
    strSQL = strSQL & " where num_Ven='" & Me.Tag & "' "
    Banco.Execute strSQL
    
    
    P_Status ""
End Sub
Sub P_buscaitens()
    Dim strSQL As String
    On Error GoTo trata_erro
    strSQL = "select tv.*,tp.*,tg.nome_cat,tg.nome_cat,"
    strSQL = strSQL & "te.nome_mar,te.cod_mar,ti.*,(ti.unit_ite*ti.qtd_ite) as total "
    strSQL = strSQL & " from tab_produtos as tp,tab_vendas as tv, tab_categorias as tg,"
    strSQL = strSQL & " tab_marcas as te, tab_Itvendas as ti   "
    strSQL = strSQL & " where tp.cod_pro=ti.cod_pro and tp.cod_cat=tg.cod_cat "
    
    strSQL = strSQL & " and tp.cod_mar=te.cod_mar "
    strSQL = strSQL & " and ti.num_ven=tv.num_ven and tv.num_ven='" & Me.Tag & "' "
    strSQL = strSQL & " order by seq_ite "
    dtProd.RecordSource = strSQL
    dtProd.Refresh
    
            
    Exit Sub
trata_erro:
    MsgBox Err.Description, vbExclamation
End Sub


Sub P_InsereProd(sCod_Pro As String, cUnit As Currency, cQtd As Currency)
    Dim strSQL As String
    Dim iIndex As Integer
    strSQL = F_BuscaUmCampo("max(seq_ite)", "tab_itvendas", "num_ven='" & Me.Tag & "'")
'    If strSQL = "" Then
'        iIndex = 1
'    Else
'        iIndex = val(strSQL) + 1
'    End If
    strSQL = "insert into tab_itvendas(num_ven,cod_pro,unit_ite,qtd_ite,seq_ite,final_ite)values("
    
    strSQL = strSQL & "'" & Me.Tag & "', "
    strSQL = strSQL & "'" & sCod_Pro & "',"
    strSQL = strSQL & F_GravaDec(CStr(cUnit)) & ","
    strSQL = strSQL & F_GravaDec(CStr(cQtd)) & ","
    strSQL = strSQL & iItem & ","
    
    strSQL = strSQL & F_GravaDec(cUnit * cQtd) & ") "
    Banco.Execute strSQL
    'RESERVANDO O ESTOQUE
    strSQL = "update tab_produtos set er_pro=er_pro - " & F_GravaDec(CStr(cQtd))
    strSQL = strSQL & " where cod_pro='" & sCod_Pro & "' "
    Banco.Execute strSQL
        
End Sub
Sub P_AumentaQTD(sCod_Pro As String, cQtd As Currency)
    Dim strSQL As String
    Dim iIndex As Integer
    
    strSQL = "Update tab_itvendas set "
    
    strSQL = strSQL & "qtd_ite = qtd_ite+"
    strSQL = strSQL & F_GravaDec(CStr(cQtd)) & " "
    strSQL = strSQL & " where num_ven='" & Me.Tag & "'  "
    strSQL = strSQL & " and cod_pro ='" & sCod_Pro & "' "
    Banco.Execute strSQL
    
    
    
    'RESERVANDO O ESTOQUE
    strSQL = "update tab_produtos set er_pro=er_pro - " & F_GravaDec(CStr(cQtd))
    strSQL = strSQL & " where cod_pro='" & sCod_Pro & "' "
    Banco.Execute strSQL
    
End Sub



Private Sub cmbxBuscar_Click()
    If cmbxBuscar.ListIndex = 0 Then
       cmndbtnLocaliza.Tag = "B"
    Else
        cmndbtnLocaliza.Tag = Left(cmbxBuscar.Text, 1)
    End If
End Sub

Private Sub cmbxBuscar_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
        SendKeys Chr(9)
    End If
End Sub

Private Sub cmndbtnCancel_Click()
    Dim strSQL  As String
    Dim i As Integer
    If dtProd.Recordset.RecordCount > 0 Then
    
    If strExclVenda_usu <> "S" Then
        strSQL = F_senhaReturnUsu
        If F_BuscaUmCampo("exclvenda_usu", "tab_defusu", "cod_usu='" & strSQL & "'") <> "S" Then
            MsgBox "Usu�rio N�o Autorizado!", vbCritical
            Exit Sub
        End If
    End If
    End If
    If MsgBox("Tem certeza que deseja cancelar esta venda?", vbYesNo + vbCritical) = vbYes Then
        If operacao = "C" Then
            i = F_RetornoVariaveis
            If i Mod 2 > 0 Then
                Bematech_FI_CancelaCupom
            End If
        End If
        With dtProd.Recordset
            If .RecordCount > 0 Then .MoveFirst
            Do While Not .EOF
                    
                excluir False
                .MoveNext
            Loop
        End With
        strSQL = "delete from tab_vendas where num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        strSQL = "delete from tab_itvendas where num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        
                
        If IsLoad("frmEdiVendas") Then
            RefreshDataPosition frmEdiVendas.dtVendas
        End If
        
        If MsgBox("Deseja Gerar uma Nova Venda?" & Chr(13) & "Clique em n�o caso queira abandonar o modo de vendas!", vbYesNo + vbQuestion) = vbYes Then
            strSQL = F_GeraNovaVenda("00000", strCod_Usu)
            iItem = 0
            Me.Tag = strSQL
            Form_Activate
        Else
            Unload Me
        End If
    End If
End Sub



Private Sub cmndbtnEditProd_Click()
    On Error GoTo trata_erro
    Dim iPos As Integer
    Dim strSQL As String
    Dim cUlt_Qtd As Currency
    
    With dtProd.Recordset
        If .RecordCount = 0 Then
            Exit Sub
        End If
        
        iPos = .AbsolutePosition
        frmValoresProd.lblCod_Pro.caption = !cod_pro
        frmValoresProd.lblNome_pro.caption = !nome_pro
        frmValoresProd.txtbxCusto.Text = FormatVal(!custo_pro)
        frmValoresProd.txtbxPreco.Text = FormatVal(!unit_ite)
        frmValoresProd.txtbxQtd.Text = FormatVal(!qtd_ite)
        frmValoresProd.Tag = Me.Tag
        cUlt_Qtd = !qtd_ite
        On Error Resume Next
        frmValoresProd.Show 1
        If CCur(frmValoresProd.txtbxQtd.Text) <= 0 Then
            MsgBox "Informe um valor decente!", vbExclamation
            Exit Sub
        End If
        strSQL = "Update tab_itvendas set qtd_ite=" & _
        F_GravaDec(frmValoresProd.txtbxQtd.Text)
        strSQL = strSQL & ", unit_ite=" & _
        F_GravaDec(frmValoresProd.txtbxPreco.Text)
        
        strSQL = strSQL & " where num_ven='" & Me.Tag & "' "
        strSQL = strSQL & " and cod_pro='" & !cod_pro & "' "
        Banco.Execute strSQL
        'ajustando estoque reservado
        strSQL = "Update tab_produtos set reservado_pro=reservado_pro-" & F_GravaDec(CStr(cUlt_Qtd))
        strSQL = strSQL & "+" & F_GravaDec(frmValoresProd.txtbxQtd.Text)
        strSQL = strSQL & " where cod_pro='" & !cod_pro & "' "
        Banco.Execute strSQL
        Unload frmValoresProd
    End With
    dtProd.Refresh
    dtProd.Recordset.Move iPos
    P_AtualizaVenda
trata_erro:
End Sub

Private Sub cmndbtnExc_Prod_Click()
    excluir True
End Sub
Sub excluir(bQuestion As Boolean)
    Dim iPos As Integer
    Dim strSQL As String
    Dim rPesq As Recordset
    With dtProd.Recordset
        If .RecordCount = 0 Then
            Exit Sub
        End If
        If bQuestion = True Then
            If MsgBox("Confirma Exclus�o do Produto " & !nome_pro & "?", _
            vbCritical + vbYesNo) = vbNo Then
                Exit Sub
            End If
        End If
        
        iPos = .AbsolutePosition
        strSQL = "delete from tab_itvendas where seq_ite='" & !seq_ite & "' "
        
        strSQL = strSQL & " and num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        'ajustando estoque reservado
        strSQL = "update tab_produtos set er_pro=er_pro + " & F_GravaDec(CStr(!qtd_ite))
        strSQL = strSQL & " where cod_pro='" & !cod_pro & "' "
        Banco.Execute strSQL
        
        dtProd.Refresh
        If iPos = .RecordCount - 1 Then
            If dtProd.Recordset.RecordCount > 0 Then
                dtProd.Recordset.MoveLast
            End If
        Else
            dtProd.Recordset.Move iPos
        End If
        P_AtualizaVenda
        If dtProd.Recordset.RecordCount = 0 Then
            txtbxQtd.Enabled = False
            txtbxProduto.Enabled = True
            txtbxProduto.SetFocus
        End If
    End With
End Sub
Private Sub cmndbtnExc_serv_Click()
    Dim iPos As Integer
    Dim strSQL As String
    With dtServ.Recordset
        If MsgBox("Confirma Exclus�o do Servi�o " & !Descricao_Ser & "?", _
        vbQuestion + vbYesNo) = vbNo Then
            Exit Sub
        End If
        iPos = .AbsolutePosition
        strSQL = "delete from tab_venserv where cod_ser='" & !cod_ser & "' "
        strSQL = strSQL & " and num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        strSQL = "delete from tab_funserv where "
        strSQL = strSQL & "  item_ser='" & dtServ.Recordset!item_ser & "' "
        Banco.Execute strSQL
        dtServ.Refresh
        If iPos = .RecordCount - 1 Then
            If dtServ.Recordset.RecordCount > 0 Then
                dtServ.Recordset.MoveLast
            End If
        Else
            dtServ.Recordset.Move iPos
        End If
        P_AtualizaVenda
    End With
End Sub

Private Sub cmndbtnExcEx_Click()
    Dim iPos As Integer
    Dim strSQL As String
    Dim rPesq As Recordset
    With dtExt.Recordset
        If MsgBox("Confirma Exclus�o do Produto " & !nome_pro & "?", _
        vbCritical + vbYesNo) = vbNo Then
            Exit Sub
        End If
        iPos = .AbsolutePosition
        strSQL = "delete from tab_venped where cod_pro='" & !cod_pro & "' "
        strSQL = strSQL & " and num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        'ajustando estoque reservado
        
        
        dtExt.Refresh
        
        P_AtualizaVenda
    End With

End Sub

Private Sub cmndbtnExcl_Pre_Click()
    Dim strSQL As String
    Dim rPesq As Recordset
    With dtPre.Recordset
        If MsgBox("Confirma Exclus�o do Produto " & !nome_pro & "?", _
        vbCritical + vbYesNo) = vbNo Then
            Exit Sub
        End If
        
        strSQL = "delete from tab_prevendas where cod_pro='" & !cod_pro & "' "
        strSQL = strSQL & " and num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        'ajustando estoque reservado
        
        
        dtPre.Refresh
        
        P_AtualizaVenda
    End With

End Sub

Private Sub cmndbtnFornada_Click()
    If dbgrdProd.Row = -1 Then
        MsgBox "Selecione um Produto!", vbExclamation
        dbgrdProd.SetFocus
        Exit Sub
    End If
    If dtProd.Recordset.RecordCount = 0 Then
        MsgBox "N�o h� produtos!", vbExclamation
        Exit Sub
    End If
    If val(dtProd.Recordset!pei_pro) = 0 Then
        MsgBox "Este produto n�o possui fornadas!", vbExclamation
        Exit Sub
    End If
    With frmVendaFornadas
        
        
        .Tag = dtProd.Recordset!cod_pro
        .frControle.caption = dtProd.Recordset!nome_pro
        .lblQtd_Ite.caption = FormatVal(dtProd.Recordset!qtd_ite)
        .lblVenda.caption = Me.Tag
        
        .Show 1
    End With
End Sub

Private Sub cmndbtnCliente_Click()
     
        frmSelectCli.txtbxNome.Tag = "C"
        frmSelectCli.txtbxNome.Text = txtbxNomeCli.Text
    
    On Error Resume Next
    
    frmSelectCli.Show 1
    
    If F_BuscaUmCampo("status_cli", "tab_clientes", "cod_cli='" & _
        frmSelectCli.dtBusca.Recordset!COD & "'") <> "1" Then
        MsgBox "Este cliente est� negativado! " & Chr(13) & _
            "A venda s� poder� ser fechada a vista ou a cart�o. ", vbCritical
    End If
    
    txtbxNomeCli.Text = frmSelectCli.dtBusca.Recordset!nome
    txtbxNomeCli.Tag = frmSelectCli.dtBusca.Recordset!COD
    txtbxCod_Cli.Text = frmSelectCli.dtBusca.Recordset!COD
    
    
    
    Unload frmSelectCli
    
End Sub

Private Sub cmndbtnLocaliza_Click()
    insere
End Sub

Private Sub cmndbtnSair_Click()
    Dim strSQL As String
    On Error GoTo trata_erro
    If dtProd.Recordset.RecordCount > 0 Then
        
        MsgBox "Imposs�vel Abandonar a Venda!", vbCritical
        Exit Sub
    End If
    If IsLoad(frmEdiVendas.Name) Then
        frmEdiVendas.dtVendas.Refresh
    End If
    If dtProd.Recordset.RecordCount = 0 Then
        strSQL = "delete from tab_vendas where num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        strSQL = "delete from tab_itvendas where num_ven='" & Me.Tag & "' "
        Banco.Execute strSQL
        
    End If
    i = F_RetornoVariaveis
        If i Mod 2 > 0 Then
            Bematech_FI_CancelaCupom
        End If
    
    Unload Me
    Exit Sub
trata_erro:
    P_MostraErro
    
End Sub


Private Sub cmndbtnSalvar_Click()
    Dim sTroco As String
    Dim strSQL As String
    Dim sVen As String
    If dtProd.Recordset.RecordCount = 0 Then
        MsgBox "N�o h� itens na sua venda!", vbExclamation
        Exit Sub
    End If
    
    
    strSQL = "update tab_itvendas set final_ite=(qtd_ite*unit_ite) "
    strSQL = strSQL & " where num_ven='" & Me.Tag & "' "
    Banco.Execute strSQL
    
    sTroco = F_Troco(CCur(lblValor.caption), Me.Tag, sVen, txtbxNomeCli.Tag, txtbxNomeCli.Text, operacao)
    If sTroco <> "" Then
        strSQL = F_GeraNovaVenda("00000", strCod_Usu)
        iItem = 0
        Me.Tag = strSQL
        lblNum_Ven.caption = strSQL
        P_buscaitens
        P_AtualizaVenda
        txtbxProduto.Text = ""
        txtbxProduto.SetFocus
        dtProd.Refresh
    End If
End Sub


Private Sub dbgrdProd_DblClick()
    cmndbtnEditProd_Click
End Sub

Private Sub dbgrdProd_GotFocus()
    
    dbgrdProd.MarqueeStyle = 3
    
    
End Sub

Private Sub dbgrdProd_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyF3 Then
        editaItem
    ElseIf KeyCode = vbKeyDelete Then
        
        If operacao = "C" Then
            If dtProd.Recordset.RecordCount = 1 Then
                i = Bematech_FI_CancelaCupom
            Else
            
                i = Bematech_FI_CancelaItemGenerico(dtProd.Recordset!seq_ite)
            End If
            excluir False
            
        Else
            excluir False
        End If
    ElseIf KeyCode = vbKeyP Or KeyCode = vbKeyReturn Then
        txtbxProduto_GotFocus
        txtbxProduto.SetFocus
    End If
End Sub

Private Sub dbgrdProd_LostFocus()
    dbgrdProd.MarqueeStyle = 0
End Sub


Private Sub dtProd_Reposition()
    With dtProd.Recordset
    On Error Resume Next
    If Not .EOF Then
        lblProduto.caption = !nome_pro
            
            If !prom_pro = "S" Then
                lblPreco.caption = "R$ " & FormatVal(!p3_pro)
                lblCapPreco.caption = "Promo��o!!!"
            Else
                lblCapPreco.caption = "Pre�o:"
                lblPreco.caption = "R$ " & FormatVal(!p2_pro)
            End If
            lblCat.caption = !nome_cat
            lblCod.caption = FormatCodigo(!cod_pro)
            lblCodBarr.caption = F_BuscaUmCampo("codbarra_pro", "tab_codbarras", "cod_pro='" & !cod_pro & "'")
            lblMarca.caption = !nome_mar
            lblQtd.caption = !qtd_ite
            lblRef.caption = !codfab_pro
        End If
    End With
        
End Sub

Private Sub Form_Activate()
    lblNum_Ven.caption = Me.Tag
    lblNome_Fun.caption = strCod_Usu & "-" & strNome_Usu
    lblNomeEmp.caption = strFantasia_Emp
    lblCaixa = strCod_Cai
    lblTur.caption = strCod_Tur
    If bActive = True Then Exit Sub
    P_Status "Buscando Itens..."
    txtbxProduto.SetFocus
    P_buscaitens
    P_AtualizaVenda
    P_Status ""
    bActive = True
    If strCod_Cai = "" Then
        MsgBox "N�o existe caixa para este computador, o caixa ficar� para o '01' ", vbExclamation
        strCod_Cai = "01"
    End If
    playGif
End Sub
Sub playGif()
    'WebBrowser1.Navigate "c:\market\gifs\maebela2.gif"
    'WebBrowser1.Navigate "about:<html><body scroll='no'><img src='c:\maebela.gif'></img></body></html>"
    
End Sub

    


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyF3 Then
        editaItem
    ElseIf KeyCode = vbKeyF5 Then
        
        dbgrdProd.SetFocus
    ElseIf KeyCode = vbKeyF4 Then
         dbgrdProd_KeyDown vbKeyDelete, 0
    ElseIf KeyCode = vbKeyF6 Then
        cmndbtnCancel_Click
    ElseIf KeyCode = vbKeyF7 Then
        
        cmndbtnSalvar_Click
    ElseIf KeyCode = vbKeyF2 Then
        txtbxProduto_KeyDown 13, 0
    ElseIf KeyCode = vbKeyF8 Then
        If operacao = "B" And dtProd.Recordset.RecordCount > 0 Then
            MsgBox "Operaca��o Imposs�vel!", vbCritical
            Exit Sub
        End If
        pcECF.BackColor = vbGreen
        operacao = "C"
    ElseIf KeyCode = vbKeyF9 Then
        If operacao = "C" And dtProd.Recordset.RecordCount > 0 Then
            MsgBox "Operaca��o Imposs�vel!", vbCritical
            Exit Sub
        End If
        pcECF.BackColor = vbYellow
        operacao = "B"
    
        
    ElseIf KeyCode = vbKeyF12 Then
        cmndbtnSair_Click
    End If
End Sub

Private Sub Form_Load()

    bActive = False

    dtProd.Connect = Banco.Connect

    lblNomeEmp.caption = strNome_Emp
    lblProp.caption = F_BuscaUmCampo("msgvenda_par", "tab_parametros", "")
    txtbxNomeCli.Tag = "00000"
    txtbxNomeCli.Text = "VENDA A CONSUMIDOR"
    
    
    
    
'    cmbxBuscar.ListIndex = 0
    'pcECF.BackColor = vbGreen
    pcECF.BackColor = vbYellow
    'operacao = "C"
    operacao = "B"
    
End Sub

Private Sub Form_Resize()
'    If Me.Width > 11115 Then
'        Me.Width = 11115
'    End If
'    If Me.Height > 6750 Then
'        Me.Height = 6750
'    End If
    
    
End Sub
Sub editaItem()
    txtbxQtd.Enabled = True
    txtbxQtd.Text = "1"
    txtbxQtd.SetFocus
End Sub

Private Sub optnCod_Click()
    txtbxProduto.SetFocus
End Sub

Private Sub optnDesc_Click()
    txtbxProduto.SetFocus
End Sub

Private Sub optnEnd_Click()
    
End Sub

Private Sub optnSeq_Click()
    P_buscaitens
End Sub
Function ConfereFornadas() As Boolean
    Dim strSQL As String
    Dim sMsg As String
    Dim bForn As Boolean
    With dtProd.Recordset
        bForn = True
        If .RecordCount > 0 Then
            .MoveFirst
        End If
        Do While Not .EOF
            If val(!pei_pro) > 0 Then
                strSQL = F_BuscaUmCampo("sum(qtd_ite)", "tab_venforn", _
                    "num_ven='" & Me.Tag & "'")
                If strSQL = "" Then
                    strSQL = "0"
                End If
                If CCur(strSQL) < !qtd_ite Then
                    sMsg = sMsg & "No Item (" & .AbsolutePosition + 1 & ")  " & Format(!cod_pro, "00#\.###\-#") & " Restam distribuir " & !qtd_ite - CCur(strSQL) & " Itens " & Chr(13)
                    bForn = False
                End If
                    
                
            End If
            .MoveNext
        Loop
        ConfereFornadas = bForn
        If bForn = False Then
            sMsg = sMsg & Chr(13) & "Selecione o produto descrito e clique em 'Fornadas'"
            MsgBox "Distribui��o de Fornadas Incompleta: " & Chr(13) & sMsg, vbCritical
            
        End If
    End With
End Function


Private Sub SSTab1_DblClick()

End Sub

Private Sub sstb_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
        If sstb.Tab = 0 Then
            cmndbtnAddProd.SetFocus
        ElseIf sstb.Tab = 1 Then
            cmndbtnAddExr.SetFocus
        ElseIf sstb.Tab = 2 Then
            cmndbtnAddPre.SetFocus
        
        End If
    End If
End Sub

Private Sub txtbxEndereco_ven_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
    SendKeys Chr(9)
        End If
End Sub

Private Sub Timer1_Timer()
    'DoEvents
    lblProp.Left = lblProp.Left - 150
    iGif = iGif + 1
    If lblProp.Left <= -lblProp.Width Then
        lblProp.Left = pcPro.Width
        lblProp.ForeColor = RGB(Int((1000 * Rnd) + 1), Int((100 * Rnd) + 1), Int((1000 * Rnd) + 1))
    End If
    If iGif = 50 Then
        QProGIF1.Visible = False
    End If
    If iGif >= 100 Then
        QProGIF1.Visible = True
        iGif = 0
    End If
    lblHora.caption = Now
    lblHora.Refresh
   End Sub

Private Sub txtbxCod_Cli_GotFocus()
    P_SelecTexto txtbxCod_Cli
End Sub

Private Sub txtbxCod_Cli_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
        SendKeys Chr(9)
        
    End If
End Sub
Sub buscaCodCli()
    Dim strSQL As String
    
    strSQL = F_BuscaUmCampo("nome_cli", "tab_clientes", "cod_cli='" & _
        txtbxCod_Cli.Text & "'")
    
    If strSQL = "" Then
        MsgBox "Cliente n�o encontrado!", vbExclamation
        txtbxCod_Cli.Text = ""
        txtbxCod_Cli.SetFocus
    Else
        txtbxNomeCli.Text = strSQL
        txtbxNomeCli.Tag = txtbxCod_Cli.Text

    End If
    
    
End Sub
Private Sub txtbxCod_Cli_LostFocus()
    If txtbxCod_Cli.Text = "" Then Exit Sub
    P_AjustaTexto txtbxCod_Cli
    txtbxCod_Cli.Text = Format(txtbxCod_Cli.Text, "0000#")
    
    buscaCodCli
End Sub

Private Sub txtbxNomeCli_GotFocus()
    P_SelecTexto txtbxNomeCli
End Sub

Private Sub txtbxNomeCli_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
        cmndbtnCliente_Click
    End If
End Sub

Private Sub txtbxNomeCli_LostFocus()
    P_AjustaTexto txtbxNomeCli
    If txtbxNomeCli.Tag <> "" Then
        P_AtualizaVenda
    End If
End Sub

Private Sub txtbxObs_GotFocus()
    
End Sub

Private Sub txtbxObs_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyReturn Then
        SendKeys Chr(9)
    End If
End Sub

Private Sub txtbxObs_LostFocus()
    
End Sub

Private Sub txtbxProduto_GotFocus()
    P_SelecTexto txtbxProduto
End Sub

Private Sub txtbxProduto_KeyDown(KeyCode As Integer, Shift As Integer)
    Dim iPos As Integer
    Dim p As Produto
    Dim rPesq As Recordset
    If KeyCode = vbKeyReturn Then
        cmndbtnLocaliza_Click

    ElseIf KeyCode = vbKeyTab Then
        txtbxQtd.Enabled = True
    ElseIf KeyCode = vbKeyDown Then
        dbgrdProd.SetFocus
    ElseIf KeyCode = vbKeyF6 Then
        'cmndbtnLocaliza_Click
    ElseIf KeyCode = vbKeyF11 Then
        
        frmReemissao.Show 1
    End If
    
End Sub
Sub insere()
    Dim iPos As Integer
    Dim i As Integer
    Dim e As EstadoImp
    Dim p As Produto
    Dim rPesq As Recordset
            
            
            
            
            p = F_BuscaProdSaida(txtbxProduto.Text, "B")
            If p.cod_pro <> "" Then
                
                txtbxProduto.Text = p.nome_pro
                
                
                
                lblNome_pro.caption = p.nome_pro
                
                
                If p.p2_pro = 0 Then
                    MsgBox "Este produto encontra-se com o pre�o de venda zerado!", vbCritical
                    Exit Sub
                End If
            lblNome_pro.caption = p.nome_pro
            
                    
                    iItem = iItem + 1
                    P_InsereProd p.cod_pro, p.p2_pro, CCur(txtbxQtd.Text)
                    
                     P_buscaitens
                            Me.Refresh
                            If operacao = "C" Then
                            i = F_RetornoVariaveis
                            If i = 4 Or i = 36 Then
                                strNum_Cpm = "       "
                                i = Bematech_FI_NumeroCupom(strNum_Cpm)
                                P_Msg "Abrindo Cupom Fiscal..."
                                
                                i = Bematech_FI_AbreCupom("")
                                P_Msg ""
                            End If
                            P_Msg "Registrando Item... " & p.nome_pro
                              If p.s_pro = "R" Then
                                p.ecf_icms = "FF"
                            ElseIf p.s_pro = "I" Then
                                p.ecf_icms = "II"
                            ElseIf p.s_pro = "" Then
                                p.ecf_icms = "01"
                            End If
                            
                            i = Bematech_FI_VendeItem(p.cod_pro, Left(p.nome_pro, 29), p.ecf_icms, "I", txtbxQtd.Text, 2, CStr(p.p2_pro), "%", "0")
                            P_Msg ""
                        End If
                   txtbxQtd.Text = "1"
                    dtProd.Recordset.Move dtProd.Recordset.RecordCount - 1
                    txtbxProduto_GotFocus
                    txtbxProduto.SetFocus
                    
                
        End If
        
        P_AtualizaVenda
        On Error Resume Next
        rPesq.Close
        
End Sub
Private Sub txtbxQtd_GotFocus()
    
    P_SelecTexto txtbxQtd
End Sub

 Private Sub txtbxQtd_KeyDown(KeyCode As Integer, Shift As Integer)
    
    On Error GoTo trata_erro
    If KeyCode = vbKeyReturn Then
        If CCur(txtbxQtd.Text) = 0 Then
            MsgBox "O Valor Informado n�o est� Correto!", vbCritical
            txtbxQtd.SetFocus
            Exit Sub
        End If
        txtbxQtd.Enabled = False
        txtbxProduto.SetFocus
    End If
Exit Sub
trata_erro:
    MsgBox Err.Description, vbcre
End Sub

Private Sub txtbxQtd_LostFocus()
    On Error Resume Next
    
    txtbxQtd.Enabled = False
    txtbxProduto.Text = ""
    txtbxProduto.Enabled = True
    txtbxProduto.SetFocus
    
    
    
End Sub

Private Sub WebBrowser1_StatusTextChange(ByVal Text As String)
    Timer1_Timer
End Sub

Private Sub txtbxUnit_LostFocus()
    P_ValorLostFocus txtbxUnit, "###,##0.000"
End Sub
